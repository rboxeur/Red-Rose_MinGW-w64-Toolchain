/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER.PD within this package.
 *
 * Written by Kai Tietz  <kai.tietz@onevision.com>
 */

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <sect_attribs.h>
#include <corecrt_startup.h>

static _CRTALLOC(".CRT$XDA") const _PVFV __xd_a = 0;
static _CRTALLOC(".CRT$XDZ") const _PVFV __xd_z = 0;

void WINAPI __dyn_tls_init (HANDLE, DWORD, LPVOID);

void WINAPI
__dyn_tls_init (HANDLE hDllHandle __attribute__((unused)), DWORD dwReason, LPVOID lpreserved __attribute__((unused)))
{
  _PVFV *pfunc;
  uintptr_t ps;

  if (dwReason != DLL_THREAD_ATTACH)
    {
      return;
    }

  ps = (uintptr_t) &__xd_a;
  ps += sizeof (uintptr_t);
  for ( ; ps != (uintptr_t) &__xd_z; ps += sizeof (uintptr_t))
    {
      pfunc = (_PVFV *) ps;
      if (*pfunc != NULL)
	(*pfunc)();
    }
}

const PIMAGE_TLS_CALLBACK __dyn_tls_init_callback = __dyn_tls_init;
static _CRTALLOC(".CRT$XLC") const PIMAGE_TLS_CALLBACK __xl_c = __dyn_tls_init;

/* Force tlssup.c (_tls_used symbol for .tls linker section) to be linked.  */
extern const IMAGE_TLS_DIRECTORY _tls_used;
static __attribute__((destructor)) void _include_tls_used(void) { asm volatile ("" :: "r" (&_tls_used)); }
